
import React from 'react'
import Dashbaord from './Dashboard'
import Navbar from './Navbar'

export default function Home() {
  return (
    <div>
      
    <Dashbaord/>
    </div>
  )
}
